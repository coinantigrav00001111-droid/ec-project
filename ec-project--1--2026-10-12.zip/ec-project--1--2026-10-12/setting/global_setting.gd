class_name GlobalSetting extends Resource

##########################
## Настройки объектов
###########################
## Подключаются в синглтоне Global


######### TRACK ##############
@export_group("Tracks")
@export var track_head_segment  = {
	'align_ends' : false, # Выравнивание торцов
	'deg_per_segment' : 10.0, # сколько градусов закрывает один сегмент
	'gap' : 0.0, # зазор между сегментами.
	"size" : Vector2(0.2, 0.25), # (1.65 + 0,1 +0,1) = 1.85 или 0.2, если 2шт
	'start_end_padding' : -0.2,	 #  минус - внутрь трака, плюс =0 
	'offset_x' : 0.875, # 0, или 0.875-смещение влево относительно центра 0.1 -по z, если 2шт
	'static_generation_ballast' : true, # Метод генерации статикбоди трака
	'static_generation_heads' : 2,
	}

@export var track_ballast_segment = {
	'align_ends' : false, # Выравнивание торцов
	'deg_per_segment' : 10.0,
	"gap" : 0.0,
	"size" : Vector2(3.2, 0.6),
	'start_end_padding' : -0.2,	 #  минус - внутрь трака, плюс =0 
	'offset_x' : 0.0, #смещение влево 
}

# XX claude-terra
@export_group("Terrain")
## T - высота одного слоя (уровня) рельефа и трака, ю. 1.0 = 1 см модели
@export var layer_height := 1.0
## Шаг опор эстакады вдоль трака, ю
@export var support_step := 8.0
## Если зазор между низом балласта и землей меньше - опоры не нужны, ю
@export var support_min_clearance := 0.4
## Допустимый излом стыка по вертикали, градусы (суммарный уклон двух сторон стыка)
@export var joint_kink_max_deg := 6.0
## Радиус вертикального магнита к чужому сокету (по горизонтали), ю
@export var magnet_radius := 3.0
## Максимальная разница высот, при которой магнит еще срабатывает, ю
@export var magnet_max_dy := 6.0

## Это не исп. а для справки
@export_group("Not Used")

@export var sleeper_size  = {
	'distance' : 0.4,
	'length' : 0.3,
	'width' : 3.0,
	'height' : 0.2,
	}


## Высота трака
func get_track_height() -> float:
	return track_head_segment.size.y + track_ballast_segment.size.y

	
